# R/packages.R
# Central place to set target options + packages

library(targets)

tar_option_set(
  packages = c(
    "httr2","jsonlite","dplyr","purrr","tidyr","stringr","lubridate",
    "tibble","furrr","fs","arrow","uuid","readr","future"
  ),
  format = "rds",
  workspace_on_error = FALSE
)

# You can control parallelism globally here if desired:
# future::plan(multisession, workers = max(2, parallel::detectCores() - 2))
